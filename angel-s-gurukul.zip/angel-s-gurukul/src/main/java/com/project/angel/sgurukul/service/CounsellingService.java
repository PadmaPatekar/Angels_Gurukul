package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Counselling;

@Component
public interface CounsellingService {

	Counselling addCounselling(Counselling Counselling);
	
	List<Counselling> getAllCounselling();
	
	Counselling  getCounsellingById(Long CounsellingId);
	
	Counselling  updateCounselling(Long CounsellingId,Counselling  Counselling);
	
	void deleteCounsellingById(Long CounsellingId);
	
	void deleteAllCounselling();
	
	boolean isCounsellingExists(Long CounsellingId);
}
