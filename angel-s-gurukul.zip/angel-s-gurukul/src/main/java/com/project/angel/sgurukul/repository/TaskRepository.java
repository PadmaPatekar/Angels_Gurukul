package com.project.angel.sgurukul.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.angel.sgurukul.entity.Task;

public interface TaskRepository extends JpaRepository<Task, Long>{

}
