package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.angel.sgurukul.entity.DisabilityStatus;
import com.project.angel.sgurukul.repository.DisabilityStatusRepository;
import com.project.angel.sgurukul.service.DisabilityStatusService;

@Service
public class DisabilityStatusServiceImpl implements DisabilityStatusService {

	@Autowired
	 private DisabilityStatusRepository disabilityStatusRepo;
   
	@Override
	public DisabilityStatus addDisabilityStatus(DisabilityStatus DisabilityStatus) {
		return disabilityStatusRepo.save(DisabilityStatus);
	}

	@Override
	public List<DisabilityStatus> getAllDisabilityStatus() {
		return disabilityStatusRepo.findAll();
	}

	@Override
	public DisabilityStatus getDisabilityStatusById(Long disabilityStatusId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return disabilityStatusRepo.findById(disabilityStatusId).get();
	}

	@Override
	public DisabilityStatus updateDisabilityStatus(Long disabilityStatusId,DisabilityStatus DisabilityStatus) {
		DisabilityStatus d=disabilityStatusRepo.findById(disabilityStatusId).get();
		d.setDisability_type(DisabilityStatus.getDisability_type());
		d.setPercentage_Disability(DisabilityStatus.getPercentage_Disability());
		d.setAddress(DisabilityStatus.getAddress());
		d.setContactNo(DisabilityStatus.getContactNo());
		d.setDob(DisabilityStatus.getDob());
		d.setAge(DisabilityStatus.getAge());
		return disabilityStatusRepo.save(d);
	}

	@Override
	public void deleteDisabilityStatusById(Long disabilityStatusId) {
		disabilityStatusRepo.deleteById(disabilityStatusId);
	}

	@Override
	public void deleteAllDisabilityStatus() {
		disabilityStatusRepo.deleteAll();
		
	}

	@Override
	public boolean isDisabilityStatusExists(Long disabilityStatusId) {
		return disabilityStatusRepo.existsById(disabilityStatusId);
	}
}
