package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.DisabilityStatus;

@Component
public interface DisabilityStatusService {

	
	DisabilityStatus addDisabilityStatus(DisabilityStatus DisabilityStatus);
	
	List<DisabilityStatus> getAllDisabilityStatus();
	
	DisabilityStatus getDisabilityStatusById(Long disabilityStatusId);
	
	DisabilityStatus updateDisabilityStatus(Long disabilityStatusId,DisabilityStatus DisabilityStatus);
	
	void deleteDisabilityStatusById(Long disabilityStatusId);
	
	void deleteAllDisabilityStatus();
	
	boolean isDisabilityStatusExists(Long disabilityStatusId);
}
