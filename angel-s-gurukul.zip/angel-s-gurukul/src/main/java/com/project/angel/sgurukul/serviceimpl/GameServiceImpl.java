package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.angel.sgurukul.entity.Game;
import com.project.angel.sgurukul.repository.GameRepository;
import com.project.angel.sgurukul.service.GameService;

public class GameServiceImpl implements GameService {

	@Autowired
	 private GameRepository GameRepo;

	@Override
	public Game addGame(Game Game) {
		return GameRepo.save(Game);
	}

	@Override
	public List<Game> getAllGame() {
		return GameRepo.findAll();
	}

	@Override
	public Game getGameById(Long GameId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return GameRepo.findById(GameId).get();
	}

	@Override
	public Game updateGame(Long GameId,Game Game) {
		Game g=GameRepo.findById(GameId).get();
		g.setName(Game.getName());
		g.setScore(Game.getScore());
		
			
		return GameRepo.save(g);
	}

	@Override
	public void deleteGameById(Long GameId) {
		GameRepo.deleteById(GameId);
	}

	@Override
	public void deleteAllGame() {
		GameRepo.deleteAll();
		
	}

	@Override
	public boolean isGameExists(Long GameId) {
		return GameRepo.existsById(GameId);
	}
}
