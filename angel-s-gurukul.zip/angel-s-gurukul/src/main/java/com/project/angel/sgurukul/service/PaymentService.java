package com.project.angel.sgurukul.service;
import java.util.List;
import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Payment;

@Component
public interface PaymentService {
    Payment addPayment(Payment Payment);
	
	List<Payment> getAllPayment();
	
	Payment  getPaymentById(Long paymentId);
	
	Payment  updatePayment(Long paymentId,Payment  Payment );
	
	void deletePaymentById(Long paymentId);
	
	void deleteAllPayment();
	
	boolean isPaymentExists(Long paymentId);
}
