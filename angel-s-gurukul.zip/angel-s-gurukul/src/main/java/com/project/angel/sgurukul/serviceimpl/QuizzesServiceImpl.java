package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.angel.sgurukul.entity.Quizzes;
import com.project.angel.sgurukul.repository.QuizzesRepository;
import com.project.angel.sgurukul.service.QuizzesService;

@Service
public class QuizzesServiceImpl implements  QuizzesService {

	@Autowired
	 private  QuizzesRepository  quizzesRepo;
   
	@Override
	public  Quizzes addQuizzes(Quizzes  Quizzes) {
		return quizzesRepo.save(Quizzes);
	}

	@Override
	public List< Quizzes> getAllQuizzes() {
		return  quizzesRepo.findAll();
	}

	@Override
	public  Quizzes getQuizzesById(Long  quizzesId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return  quizzesRepo.findById(quizzesId).get();
	}

	@Override
	public  Quizzes updateQuizzes(Long quizzesId,Quizzes  Quizzes) {
		 Quizzes q=quizzesRepo.findById(quizzesId).get();
		q.setQuizze_date(Quizzes.getQuizze_date());
		q.setTitle(Quizzes.getTitle());
		q.setTotal_questions(Quizzes.getTotal_questions());
		q.setTotal_marks(Quizzes.getTotal_marks());
		q.setQuestion(Quizzes.getQuestion());
		q.setChoice(Quizzes.getChoice());
		return quizzesRepo.save(q);
	}

	@Override
	public void deleteQuizzesById(Long quizzesId) {
		quizzesRepo.deleteById(quizzesId);
	}

	@Override
	public void deleteAllQuizzes() {
		quizzesRepo.deleteAll();
		
	}

	@Override
	public boolean isQuizzesExists(Long quizzesId) {
		return quizzesRepo.existsById(quizzesId);
	}
}
