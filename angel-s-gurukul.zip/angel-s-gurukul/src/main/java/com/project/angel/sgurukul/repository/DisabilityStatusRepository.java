package com.project.angel.sgurukul.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.angel.sgurukul.entity.DisabilityStatus;

public interface DisabilityStatusRepository extends JpaRepository<DisabilityStatus, Long> {

}
