package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Registration;
import com.project.angel.sgurukul.service.RegistrationService;

@RestController
@RequestMapping("/registrations")
public class RegistrationController {
	
	@Autowired
	private RegistrationService RegistrationService;
	
	@PostMapping("/add")
	public ResponseEntity<Registration> addUser(@RequestBody Registration Registration)
	{
		Registration r = RegistrationService.addUser(Registration);
		return new ResponseEntity<>(r,HttpStatus.CREATED);
	}
	@GetMapping("/get/{regId}")
	public ResponseEntity<Registration> getUser(@PathVariable Long regId)
	{
		boolean isUser = RegistrationService.isUserExists(regId);
		if(isUser)
		{
			Registration r=RegistrationService.getUserById(regId);
			return new ResponseEntity<>(r,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Registration>> getAllUser(){
		return new ResponseEntity<>(RegistrationService.getAllUsers(),HttpStatus.OK);
	}
	@PutMapping("/update/{regId}")
	public ResponseEntity<Registration> updateUser(@PathVariable Long regId,@RequestBody Registration r)
	{
		boolean isUser=RegistrationService.isUserExists(regId);
		if(isUser)
		{
			return new ResponseEntity<>(RegistrationService.updateUser(regId, r),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{regId}")
	public void deleteUserById(@PathVariable Long regId)
	{
		boolean isUser=RegistrationService.isUserExists(regId);
		if(isUser)
		{
			RegistrationService.deleteUserById(regId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllUser(){
		RegistrationService.deleteAllUser();
	}
}
