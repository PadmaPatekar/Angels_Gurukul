package com.project.angel.sgurukul.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.angel.sgurukul.entity.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {

}
