package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Learning;
import com.project.angel.sgurukul.service.LearningService;

@RestController
@RequestMapping("/learning")
public class LearningController {
	@Autowired
	private LearningService LearningService;
	
	@PostMapping("/add")
	public ResponseEntity<Learning> addLearning(@RequestBody  Learning  Learning)
	{
		Learning l =  LearningService.addLearning(Learning);
		return new ResponseEntity<>(l,HttpStatus.CREATED);
	}
	@GetMapping("/get/{LearningId}")
	public ResponseEntity<Learning> getLearning(@PathVariable Long LearningId)
	{
		boolean isUser = LearningService.isLearningExists(LearningId);
		if(isUser)
		{
			Learning l= LearningService.getLearningById(LearningId);
			return new ResponseEntity<>(l,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Learning>> getAllLearning(){
		return new ResponseEntity<>(LearningService.getAllLearning(),HttpStatus.OK);
	}
	@PutMapping("/update/{LearningId}")
	public ResponseEntity<Learning> updateLearning(@PathVariable Long LearningId,@RequestBody  Learning l)
	{
		boolean isUser=LearningService.isLearningExists(LearningId);
		if(isUser)
		{
			return new ResponseEntity<>(LearningService.updateLearning(LearningId, l),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{LearningId}")
	public void deleteLearningById(@PathVariable Long LearningId)
	{
		boolean isUser=LearningService.isLearningExists(LearningId);
		if(isUser)
		{
			LearningService.deleteLearningById(LearningId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllLearning(){
       LearningService.deleteAllLearning();
	}
}
