package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Game;

import com.project.angel.sgurukul.service.GameService;
@RestController
@RequestMapping("/game")
public class GameController {

	@Autowired
	private GameService GameService;
	
	@PostMapping("/add")
	public ResponseEntity<Game> addGame(@RequestBody  Game Game)
	{
		Game g =  GameService.addGame(Game);
		return new ResponseEntity<>(g,HttpStatus.CREATED);
	}
	@GetMapping("/get/{GameId}")
	public ResponseEntity<Game> getGame(@PathVariable Long GameId)
	{
		boolean isUser = GameService.isGameExists(GameId);
		if(isUser)
		{
			Game g= GameService.getGameById(GameId);
			return new ResponseEntity<>(g,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Game>> getAllGame(){
		return new ResponseEntity<>(GameService.getAllGame(),HttpStatus.OK);
	}
	@PutMapping("/update/{GameId}")
	public ResponseEntity<Game> updateGame(@PathVariable Long GameId,@RequestBody Game g)
	{
		boolean isUser=GameService.isGameExists(GameId);
		if(isUser)
		{
			return new ResponseEntity<>(GameService.updateGame(GameId,g),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{GameId}")
	public void deleteLearningById(@PathVariable Long GameId)
	{
		boolean isUser=GameService.isGameExists(GameId);
		if(isUser)
		{
			GameService.deleteGameById(GameId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllGame(){
		GameService.deleteAllGame();
	}
}
