package com.project.angel.sgurukul.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.*;
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.PrePersist;
//import jakarta.persistence.Table;
//import jakarta.persistence.Temporal;
//import jakarta.persistence.TemporalType;
//
@Entity
@Table(name="Payments")
public class Payment {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long payment_id;
	  @SuppressWarnings("unused")
	private Registration registration;
	    @Column(nullable = false)
		private Long CardNo;
	    
	    @Column(nullable = false)
		private String CardHolderName;
	    
	    @Column(nullable = false)
	    private Date ValidFromDate;
	    
	    @Column(nullable = false)
	    private Date ValidUptoDate;
	    
	    @Column(nullable = false)
	    private Long CVV;
	    
	    @Column(nullable = false)
	    private Long Amount;
	    @Temporal(TemporalType.TIMESTAMP)
	    @Column(nullable = false)
	    private Date PaymentDate;
	    
	    private LocalDate date=LocalDate.now();
	    @PrePersist
	    private void onCreate() {
	        PaymentDate = new Date();
	 
	    
	    }
	    @ManyToOne(cascade= CascadeType.ALL)
	    @JoinColumn(name="reg_id")
	    private Registration registration1;
	    
		public Registration getRegistration() {
			return registration;
		}
		public void setRegistration(Registration registration) {
			this.registration = registration;
		}
		public Date getPaymentDate() {
			return PaymentDate;
		}
		public void setPaymentDate(Date paymentDate) {
			PaymentDate = paymentDate;
		}
		public Registration getRegistration1() {
			return registration1;
		}
		public void setRegistration1(Registration registration1) {
			this.registration1 = registration1;
		}
		public Payment() {
			super();
			
		}
		public Payment(Long CardNo,String CardHolderName, Date ValidFromDate,Date ValidUptoDate,Long CVV,Long Amount) {
			super();
			this.CardNo = CardNo;
			this.CardHolderName= CardHolderName;
			this.ValidFromDate = ValidFromDate;
			this.ValidUptoDate = ValidUptoDate;
			this.CVV =CVV;
			this.Amount = Amount;
			
		}
		public Long getCardNo() {
			return CardNo;
		}
		public void setCardNo(Long cardNo) {
			CardNo = cardNo;
		}
		public String getCardHolderName() {
			return CardHolderName;
		}
		public void setCardHolderName(String cardHolderName) {
			CardHolderName = cardHolderName;
		}
		public Date getValidFromDate() {
			return ValidFromDate;
		}
		public void setValidFromDate(Date validFromDate) {
			ValidFromDate = validFromDate;
		}
		public Date getValidUptoDate() {
			return ValidUptoDate;
		}
		public void setValidUptoDate(Date validUptoDate) {
			ValidUptoDate = validUptoDate;
		}
		public Long getCVV() {
			return CVV;
		}
		public void setCVV(Long cVV) {
			CVV = cVV;
		}
		public Long getAmount() {
			return Amount;
		}
		public void setAmount(Long amount) {
			Amount = amount;
		}
		
		
		public LocalDate getDate() {
			return date;
		}
		public void setDate(LocalDate date) {
			this.date = date;
		}
		
}
