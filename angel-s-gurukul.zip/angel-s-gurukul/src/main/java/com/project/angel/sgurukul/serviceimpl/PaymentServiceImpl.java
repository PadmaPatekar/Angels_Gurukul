package com.project.angel.sgurukul.serviceimpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.angel.sgurukul.entity.Payment;
import com.project.angel.sgurukul.repository.PaymentRepository;
import com.project.angel.sgurukul.service.PaymentService;

@Service
public class PaymentServiceImpl implements  PaymentService  {
	@Autowired
	 private PaymentRepository paymentRepo;
   
	@Override
	public Payment addPayment(Payment Payment) {
		return paymentRepo.save(Payment);
	}

	@Override
	public List<Payment> getAllPayment() {
		return paymentRepo.findAll();
	}

	@Override
	public Payment getPaymentById(Long paymentId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return paymentRepo.findById(paymentId).get();
	}

	@Override
	public Payment updatePayment(Long paymentId,Payment Payment) {
		Payment p=paymentRepo.findById(paymentId).get();
		p.setCardNo(Payment.getCardNo());
		p.setCardHolderName(Payment.getCardHolderName());
		p.setValidFromDate(Payment.getValidFromDate());
		p.setValidUptoDate(Payment.getValidUptoDate());
		p.setCVV(Payment.getCVV());
		p.setAmount(Payment.getAmount());
		return paymentRepo.save(p);
	}

	@Override
	public void deletePaymentById(Long paymentId) {
		paymentRepo.deleteById(paymentId);
	}

	@Override
	public void deleteAllPayment() {
		paymentRepo.deleteAll();
		
	}

	@Override
	public boolean isPaymentExists(Long paymentId) {
		return paymentRepo.existsById(paymentId);
	}
}
