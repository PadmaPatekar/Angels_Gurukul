package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Registration;


@Component
public interface RegistrationService {
		
	Registration addUser(Registration Registration);
	
	List<Registration> getAllUsers();
	
	Registration getUserById(Long regId);
	
	Registration updateUser(Long regId,Registration Registration);
	
	void deleteUserById(Long regId);
	
	void deleteAllUser();
	
	boolean isUserExists(Long regId);
}
