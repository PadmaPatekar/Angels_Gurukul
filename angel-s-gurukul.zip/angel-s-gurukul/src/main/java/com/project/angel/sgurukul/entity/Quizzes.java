package com.project.angel.sgurukul.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Quizzes")
public class Quizzes {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long quize_id;
	    @Column(nullable = false)
		private Date quizze_date;
	    
	    @Column(nullable = false)
		private String title;
	 
	    @Column(nullable = false)
	    private Long total_questions;
	
	    @Column(nullable = false)
      private Long total_marks;
	    
	    @Column(nullable = false)
	    private String question;
	    @Column(nullable = false)
	    private String choice;
	 
		public Quizzes() {
			super();
			
		}
		public Quizzes(Date quizze_date, String title,Long total_questions,Long total_marks,String question,String choice) {
			super();
			this.quizze_date = quizze_date;
			this.title = title;
			this.total_questions = total_questions;
			this.total_marks =total_marks;
			this.question= question;	
			this.choice=choice;
			
		}
		public Date getQuizze_date() {
			return quizze_date;
		}
		public void setQuizze_date(Date quizze_date) {
			this.quizze_date = quizze_date;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public Long getTotal_questions() {
			return total_questions;
		}
		public void setTotal_questions(Long total_questions) {
			this.total_questions = total_questions;
		}
		public Long getTotal_marks() {
			return total_marks;
		}
		public void setTotal_marks(Long total_marks) {
			this.total_marks = total_marks;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		public String getChoice() {
			return choice;
		}
		public void setChoice(String choice) {
			this.choice = choice;
		}


}
