package com.project.angel.sgurukul.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.angel.sgurukul.entity.Quizzes;

public interface QuizzesRepository extends JpaRepository<Quizzes, Long> {

}
