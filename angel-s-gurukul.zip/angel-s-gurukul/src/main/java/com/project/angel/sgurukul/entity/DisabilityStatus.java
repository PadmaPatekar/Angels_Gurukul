package com.project.angel.sgurukul.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="DisabilityStatus")
public class DisabilityStatus {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long D_id;
	    @Column(nullable = false)
		private String disability_type;
	    
	    @Column(nullable = false)
		private Long percentage_Disability;
	 
	    @Column(nullable = false)
	    private String address;
	    
	    @Column(nullable = false)
	    private Long contactNo;
	
	    @Column(nullable = false)
       private Date dob;
	    
	    @Column(nullable = false)
	    private Long age;
	    

	    @ManyToOne(cascade= CascadeType.ALL)
	    @JoinColumn(name="reg_id")
	    private Registration registration1;
	    
		public Registration getRegistration1() {
			return registration1;
		}

		public void setRegistration1(Registration registration1) {
			this.registration1 = registration1;
		}

		public DisabilityStatus() {
			super();
			
		}
		
		public DisabilityStatus(String disability_type, Long percentage_Disability, String address, Long contactNo,
				Date dob, Long age) {
			super();
			this.disability_type = disability_type;
			this.percentage_Disability = percentage_Disability;
			this.address = address;
			this.contactNo = contactNo;
			this.dob = dob;
			this.age = age;
		}

		public String getDisability_type() {
			return disability_type;
		}
		public void setDisability_type(String disability_type) {
			this.disability_type = disability_type;
		}
		public Long getPercentage_Disability() {
			return percentage_Disability;
		}
		public void setPercentage_Disability(Long percentage_Disability) {
			this.percentage_Disability = percentage_Disability;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Long getContactNo() {
			return contactNo;
		}
		public void setContactNo(Long contactNo) {
			this.contactNo = contactNo;
		}
		public Date getDob() {
			return dob;
		}
		public void setDob(Date dob) {
			this.dob = dob;
		}
		public Long getAge() {
			return age;
		}
		public void setAge(Long age) {
			this.age = age;
		}

}
