package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.angel.sgurukul.entity.Counselling;
import com.project.angel.sgurukul.repository.CounsellingRepository;
import com.project.angel.sgurukul.service.CounsellingService;

public class CounsellingServiceImpl implements  CounsellingService {


	@Autowired
	 private CounsellingRepository CounsellingRepo;
  
	@Override
	public Counselling addCounselling(Counselling Counselling) {
		return CounsellingRepo.save(Counselling);
	}

	@Override
	public List<Counselling> getAllCounselling() {
		return CounsellingRepo.findAll();
	}

	@Override
	public Counselling getCounsellingById(Long CounsellingId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return CounsellingRepo.findById(CounsellingId).get();
	}

	@Override
	public Counselling updateCounselling(Long CounsellingId,Counselling Counselling) {
		Counselling c = CounsellingRepo.findById(CounsellingId).get();
		c.setCounsellerName(Counselling.getCounsellerName());
		c.setAddress(Counselling.getAddress());
		c.setPhoneNo(Counselling.getPhoneNo());
		c.setOverview(Counselling.getOverview());
			
		return CounsellingRepo.save(c);
	}

	@Override
	public void deleteCounsellingById(Long CounsellingId) {
		CounsellingRepo.deleteById(CounsellingId);
	}

	@Override
	public void deleteAllCounselling() {
		CounsellingRepo.deleteAll();
		
	}

	@Override
	public boolean isCounsellingExists(Long CounsellingId) {
		return CounsellingRepo.existsById(CounsellingId);
	}
}
