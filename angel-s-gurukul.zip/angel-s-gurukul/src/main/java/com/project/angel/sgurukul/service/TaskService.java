package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Task;
@Component
public interface TaskService {

	Task  addTask(Task Task);
	
	List<Task > getAllTask();
	
	Task   getTaskById(Long taskId);
	
	Task   updateTask(Long taskId,Task  Task);
	
	void deleteTaskById(Long taskId);
	
	void deleteAllTask();
	
	boolean isTaskExists(Long taskId);
}
