package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Quizzes;

@Component
public interface QuizzesService {

	
	Quizzes addQuizzes(Quizzes Quizzes);
	
	List<Quizzes> getAllQuizzes();
	
	Quizzes getQuizzesById(Long quizzesId);
	
	Quizzes updateQuizzes(Long qizzesId,Quizzes Quizzes);
	
	void deleteQuizzesById(Long quizzesId);
	
	void deleteAllQuizzes();
	
	boolean isQuizzesExists(Long quizzesId);
}
