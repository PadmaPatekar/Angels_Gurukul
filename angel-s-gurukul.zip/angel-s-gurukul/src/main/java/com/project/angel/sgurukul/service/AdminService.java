package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Admin;

@Component
public interface AdminService {

	
	Admin addAdmin(Admin Admin);
	
	List<Admin> getAllAdmin();
	
	Admin getAdminById(Long adminId);
	
	Admin updateAdmin(Long adminId,Admin Admin);
	
	void deleteAdminById(Long adminId);
	
	void deleteAllAdmin();
	
	boolean isAdminExists(Long adminId);
}
