package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Faculty;
import com.project.angel.sgurukul.service.FacultyService;

@RestController
@RequestMapping("/faculty")
public class FacultyController {

	@Autowired
	private FacultyService FacultyService;
	
	@PostMapping("/add")
	public ResponseEntity<Faculty> addUser(@RequestBody Faculty Faculty)
	{
		Faculty f= FacultyService.addFaculty(Faculty);
		return new ResponseEntity<>(f,HttpStatus.CREATED);
	}
	@GetMapping("/get/{facultyId}")
	public ResponseEntity<Faculty> getUser(@PathVariable Long facultyId)
	{
		boolean isFaculty = FacultyService.isFacultyExists(facultyId);
		if(isFaculty)
		{
			Faculty f=FacultyService.getFacultyById(facultyId);
			return new ResponseEntity<>(f,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Faculty>> getAllFaculty(){
		return new ResponseEntity<>(FacultyService.getAllFaculty(),HttpStatus.OK);
	}
	@PutMapping("/update/{facultyId}")
	public ResponseEntity<Faculty> updateFaculty(@PathVariable Long facultyId,@RequestBody Faculty f)
	{
		boolean isFaculty=FacultyService.isFacultyExists(facultyId);
		if(isFaculty)
		{
			return new ResponseEntity<>(FacultyService.updateFaculty(facultyId, f),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{facultyId}")
	public void deleteFacultyById(@PathVariable Long facultyId)
	{
		boolean isFaculty=FacultyService.isFacultyExists(facultyId);
		if(isFaculty)
		{
			FacultyService.deleteFacultyById(facultyId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllFaculty(){
		FacultyService.deleteAllFaculty();
	}
}
