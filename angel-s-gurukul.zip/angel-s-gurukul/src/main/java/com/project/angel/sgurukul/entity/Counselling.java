package com.project.angel.sgurukul.entity;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.Table;

@Entity
@Table(name="Counselling")
public class Counselling {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long counseller_id;
	  
	    @Column(nullable = false)
		private String counsellerName ;
	    
	    @Column(nullable = false)
	    private String address;
	    
	    @Column(nullable = false)
	    private Long phoneNo;
	    
	    @Column(nullable = false)
	    private String overview;
	
		public Counselling() {
			super();
			
		}
		public Counselling(String counsellerName,String address,Long phoneNo,String overview) {
			super();
			this.counsellerName =counsellerName;
			this.address = address;
			this.phoneNo = phoneNo;
			this.overview = overview;
   }
		public String getCounsellerName() {
			return counsellerName;
		}
		public void setCounsellerName(String counsellerName) {
			this.counsellerName = counsellerName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public Long getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(Long phoneNo) {
			this.phoneNo = phoneNo;
		}
		public String getOverview() {
			return overview;
		}
		public void setOverview(String overview) {
			this.overview = overview;
		}
}

