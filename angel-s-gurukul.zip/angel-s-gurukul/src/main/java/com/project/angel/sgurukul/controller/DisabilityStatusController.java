package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.DisabilityStatus;
import com.project.angel.sgurukul.service.DisabilityStatusService;

@RestController
@RequestMapping("/disabilityStatus")
public class DisabilityStatusController {

	@Autowired
	private DisabilityStatusService DisabilityStatusService;
	
	@PostMapping("/add")
	public ResponseEntity<DisabilityStatus> addDisabilityStatus(@RequestBody DisabilityStatus DisabilityStatus)
	{
		DisabilityStatus d = DisabilityStatusService.addDisabilityStatus(DisabilityStatus);
		return new ResponseEntity<>(d,HttpStatus.CREATED);
	}
	@GetMapping("/get/{disabilityStatusId}")
	public ResponseEntity<DisabilityStatus> getDisabilityStatus(@PathVariable Long disabilityStatusId)
	{
		boolean isDisabilityStatus = DisabilityStatusService.isDisabilityStatusExists(disabilityStatusId);
		if(isDisabilityStatus)
		{
			DisabilityStatus d=DisabilityStatusService.getDisabilityStatusById(disabilityStatusId);
			return new ResponseEntity<>(d,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<DisabilityStatus>> getAllDisabilityStatus(){
		return new ResponseEntity<>(DisabilityStatusService.getAllDisabilityStatus(),HttpStatus.OK);
	}
	@PutMapping("/update/{disabilityStatusId}")
	public ResponseEntity<DisabilityStatus> updateDisabilityStatus(@PathVariable Long disabilityStatusId,@RequestBody DisabilityStatus d)
	{
		boolean isDisabilityStatus=DisabilityStatusService.isDisabilityStatusExists(disabilityStatusId);
		if(isDisabilityStatus)
		{
			return new ResponseEntity<>(DisabilityStatusService.updateDisabilityStatus(disabilityStatusId,d),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{disabilityStatusId}")
	public void deleteDisabilityStatusById(@PathVariable Long disabilityStatusId)
	{
		boolean isDisabilityStatus=DisabilityStatusService.isDisabilityStatusExists(disabilityStatusId);
		if(isDisabilityStatus)
		{
			DisabilityStatusService.deleteDisabilityStatusById(disabilityStatusId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllDisabilityStatus(){
		DisabilityStatusService.deleteAllDisabilityStatus();
	}
}
