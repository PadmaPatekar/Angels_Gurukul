package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Faculty;

@Component
public interface FacultyService {

    Faculty addFaculty(Faculty  Faculty);
	
	List<Faculty > getAllFaculty();
	
	Faculty getFacultyById(Long facultyId);
	
	Faculty updateFaculty(Long facultyId,Faculty  Faculty );
	
	void deleteFacultyById(Long facultyId);
	
	void deleteAllFaculty();
	
	boolean isFacultyExists(Long facultyId);
}
