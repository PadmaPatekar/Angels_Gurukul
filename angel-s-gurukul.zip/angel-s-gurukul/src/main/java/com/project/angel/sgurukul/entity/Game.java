package com.project.angel.sgurukul.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="Game")
public class Game {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long Game_id;
	   @Temporal(TemporalType.TIMESTAMP)
	    @Column(nullable = false)
	    private Date GameDate;
	    @PrePersist
	    private void onCreate() {
	        GameDate = new Date();
	    }
	    
	    @Column(nullable = false)
		private String Name;
	    
	    @Column(nullable = false)
	    private int Score;
	    
	    @ManyToOne(cascade= CascadeType.ALL)
	    @JoinColumn(name="reg_id")
	    private Registration registration1;
	
		public Date getGameDate() {
			return GameDate;
		}
		public void setGameDate(Date gameDate) {
			GameDate = gameDate;
		}
		public Registration getRegistration1() {
			return registration1;
		}
		public void setRegistration1(Registration registration1) {
			this.registration1 = registration1;
		}
		public Game() {
			super();
			
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public int getScore() {
			return Score;
		}
		public void setScore(int score) {
			Score = score;
		}
		public Game(Date GameDate, String Name,int Score) {
			super();
			this.GameDate = GameDate;
			this.Name = Name;
			this.Score = Score;
	}
		
}
