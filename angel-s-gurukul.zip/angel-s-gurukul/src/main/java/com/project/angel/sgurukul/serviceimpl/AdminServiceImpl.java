package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.angel.sgurukul.entity.Admin;
import com.project.angel.sgurukul.repository.AdminRepository;
import com.project.angel.sgurukul.service.AdminService;

public class AdminServiceImpl implements AdminService{


	@Autowired
	 private AdminRepository adminRepo;
    
	@Override
	public Admin addAdmin(Admin Admin) {
		return adminRepo.save(Admin);
	}

	@Override
	public List<Admin> getAllAdmin() {
		return adminRepo.findAll();
	}

	@Override
	public Admin getAdminById(Long adminId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return adminRepo.findById(adminId).get();
	}

	@Override
	public Admin updateAdmin(Long adminId, Admin Admin) {
		Admin a = adminRepo.findById(adminId).get();
		a.setFirstName(Admin.getFirstName());
		a.setLastName(Admin.getLastName());
		a.setEmail(Admin.getEmail());
		a.setPassword(Admin.getPassword());
		a.setConfirm_password(Admin.getConfirm_password());
		return adminRepo.save(a);
	}

	@Override
	public void deleteAdminById(Long adminId) {
		adminRepo.deleteById(adminId);
	}

	@Override
	public void deleteAllAdmin() {
		adminRepo.deleteAll();
		
	}

	@Override
	public boolean isAdminExists(Long adminId) {
		return adminRepo.existsById(adminId);
	}
}
