package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.angel.sgurukul.entity.Registration;
import com.project.angel.sgurukul.repository.RegistrationRepository;
import com.project.angel.sgurukul.service.RegistrationService;

@Service
public class RegistrationServiceImpl implements  RegistrationService {

	@Autowired
	 private RegistrationRepository regRepo;
    
	@Override
	public Registration addUser(Registration Registration) {
		return regRepo.save(Registration);
	}

	@Override
	public List<Registration> getAllUsers() {
		return regRepo.findAll();
	}

	@Override
	public Registration getUserById(Long regId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return regRepo.findById(regId).get();
	}

	@Override
	public Registration updateUser(Long regId,Registration Registration) {
		Registration r=regRepo.findById(regId).get();
		r.setFirstName(Registration.getFirstName());
		r.setLastName(Registration.getLastName());
		r.setEmail(Registration.getEmail());
		r.setPassword(Registration.getPassword());
		r.setConfirm_password(Registration.getConfirm_password());
		return regRepo.save(r);
	}

	@Override
	public void deleteUserById(Long regId) {
		regRepo.deleteById(regId);
	}

	@Override
	public void deleteAllUser() {
		regRepo.deleteAll();
		
	}

	@Override
	public boolean isUserExists(Long regId) {
		return regRepo.existsById(regId);
	}
}
