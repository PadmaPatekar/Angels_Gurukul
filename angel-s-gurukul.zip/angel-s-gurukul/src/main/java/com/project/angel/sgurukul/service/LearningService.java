package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Learning;

@Component
public interface LearningService {

	    Learning addLearning(Learning Learning);
		
		List<Learning> getAllLearning();
		
		Learning  getLearningById(Long learnId);
		
		Learning  updateLearning(Long learnId,Learning  Learning);
		
		void deleteLearningById(Long learnId);
		
		void deleteAllLearning();
		
		boolean isLearningExists(Long learnId);
}
