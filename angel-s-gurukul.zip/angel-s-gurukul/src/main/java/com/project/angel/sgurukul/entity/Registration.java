package com.project.angel.sgurukul.entity;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.*;
@Entity
@Table(name="Registration")
public class Registration {
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long reg_id;
	    @Column(nullable = false)
		private String firstName;
	    
	    @Column(nullable = false)
		private String lastName;
	 
	    @Column(nullable = false,unique = true)
	    private String email;
	
	    @Column(nullable = false)
        private String password;
	    
	    @Column(nullable = false)
	    private String confirm_password;
	    
	    @JsonIgnoreProperties
	    @OneToMany(mappedBy="Registration",cascade=CascadeType.ALL)
	    List<Payment>  Payments=new ArrayList<Payment>();
	    @JsonIgnoreProperties
        @OneToMany(mappedBy="Registration",cascade=CascadeType.ALL)
	    List<Game> Game=new ArrayList<>();
	    @JsonIgnoreProperties
	    @OneToMany(mappedBy="Registration",cascade=CascadeType.ALL)
	    List<Task> Task=new ArrayList<>();
	    @JsonIgnoreProperties
	    @OneToMany(mappedBy="Registration",cascade=CascadeType.ALL)
	    List<DisabilityStatus> DisabilityStatus=new ArrayList<>();
	    
		public List<Game> getGame() {
			return Game;
		}
		public void setGame(List<Game> game) {
			Game = game;
		}
		public List<Task> getTask() {
			return Task;
		}
		public void setTask(List<Task> task) {
			Task = task;
		}
		public List<DisabilityStatus> getDisabilityStatus() {
			return DisabilityStatus;
		}
		public void setDisabilityStatus(List<DisabilityStatus> disabilityStatus) {
			DisabilityStatus = disabilityStatus;
		}
		public Registration() {
			super();
			
		}
		public Registration(String firstName, String lastName,String email,String password,String confirm_password) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.email = email;
			this.password =password;
			this.confirm_password= confirm_password;	
		}
		public List<Payment> getPayments() {
			return Payments;
		}
		public void setPayments(List<Payment> payments) {
			Payments = payments;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getConfirm_password() {
			return confirm_password;
		}
		public void setConfirm_password(String confirm_password) {
			this.confirm_password = confirm_password;
		}
	
}
