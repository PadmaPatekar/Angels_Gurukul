package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Counselling;
import com.project.angel.sgurukul.service.CounsellingService;

@RestController
@RequestMapping("/counselling")
public class CounsellingController {
	@Autowired
	private CounsellingService CounsellingService;
	
	@PostMapping("/add")
	public ResponseEntity<Counselling> addCounselling(@RequestBody  Counselling  Counselling)
	{
		Counselling c =  CounsellingService.addCounselling(Counselling);
		return new ResponseEntity<>(c,HttpStatus.CREATED);
	}
	@GetMapping("/get/{CounsellingId}")
	public ResponseEntity<Counselling> getCounselling(@PathVariable Long CounsellingId)
	{
		boolean isUser = CounsellingService.isCounsellingExists(CounsellingId);
		if(isUser)
		{
			Counselling c= CounsellingService.getCounsellingById(CounsellingId);
			return new ResponseEntity<>(c,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Counselling>> getAllLearning(){
		return new ResponseEntity<>(CounsellingService.getAllCounselling(),HttpStatus.OK);
	}
	@PutMapping("/update/{CounsellingId}")
	public ResponseEntity<Counselling> updateCounselling(@PathVariable Long CounsellingId,@RequestBody  Counselling c)
	{
		boolean isUser=CounsellingService.isCounsellingExists(CounsellingId);
		if(isUser)
		{
			return new ResponseEntity<>(CounsellingService.updateCounselling(CounsellingId, c),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{CounsellingId}")
	public void deleteCounsellingById(@PathVariable Long CounsellingId)
	{
		boolean isUser=CounsellingService.isCounsellingExists(CounsellingId);
		if(isUser)
		{
			CounsellingService.deleteCounsellingById(CounsellingId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllCounselling(){
		CounsellingService.deleteAllCounselling();
	}
	
}
