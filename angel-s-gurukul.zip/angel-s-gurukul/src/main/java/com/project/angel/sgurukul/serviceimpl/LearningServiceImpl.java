package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.angel.sgurukul.entity.Learning;
import com.project.angel.sgurukul.repository.LearningRepository;
import com.project.angel.sgurukul.service.LearningService;

public class LearningServiceImpl implements  LearningService  {

	@Autowired
	 private LearningRepository LearningRepo;
  
	@Override
	public Learning addLearning(Learning Learning) {
		return LearningRepo.save(Learning);
	}

	@Override
	public List<Learning> getAllLearning() {
		return LearningRepo.findAll();
	}

	@Override
	public Learning getLearningById(Long LearningId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return LearningRepo.findById(LearningId).get();
	}

	@Override
	public Learning updateLearning(Long LearningId,Learning Learning) {
		Learning l=LearningRepo.findById(LearningId).get();
		l.setTitle(Learning.getTitle());
		l.setLearningType(Learning.getLearningType());
		l.setOverview(Learning.getOverview());
		l.setLink(Learning.getLink());	
		return LearningRepo.save(l);
	}

	@Override
	public void deleteLearningById(Long LearningId) {
		LearningRepo.deleteById(LearningId);
	}

	@Override
	public void deleteAllLearning() {
		LearningRepo.deleteAll();
		
	}

	@Override
	public boolean isLearningExists(Long LearningId) {
		return LearningRepo.existsById(LearningId);
	}
}
