package com.project.angel.sgurukul.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.angel.sgurukul.entity.Learning;

public interface LearningRepository extends JpaRepository<Learning, Long> {

}
