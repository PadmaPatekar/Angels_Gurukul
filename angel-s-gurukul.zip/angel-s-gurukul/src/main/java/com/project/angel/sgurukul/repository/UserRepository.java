package com.project.angel.sgurukul.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.project.angel.sgurukul.entity.User;
public interface UserRepository extends JpaRepository<User, Long> {
	 
}