package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Task;
import com.project.angel.sgurukul.service.TaskService;

@RestController
@RequestMapping("/task")
public class TaskController {

	@Autowired
	private TaskService TaskService;
	
	@PostMapping("/add")
	public ResponseEntity<Task> addTask(@RequestBody  Task  Task)
	{
		Task t =  TaskService.addTask(Task);
		return new ResponseEntity<>(t,HttpStatus.CREATED);
	}
	@GetMapping("/get/{TaskId}")
	public ResponseEntity<Task> getTask(@PathVariable Long TaskId)
	{
		boolean isUser = TaskService.isTaskExists(TaskId);
		if(isUser)
		{
			Task t= TaskService.getTaskById(TaskId);
			return new ResponseEntity<>(t,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Task>> getAllTask(){
		return new ResponseEntity<>(TaskService.getAllTask(),HttpStatus.OK);
	}
	@PutMapping("/update/{TaskId}")
	public ResponseEntity<Task> updateTask(@PathVariable Long TaskId,@RequestBody Task t)
	{
		boolean isUser=TaskService.isTaskExists(TaskId);
		if(isUser)
		{
			return new ResponseEntity<>(TaskService.updateTask(TaskId, t),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{TaskId}")
	public void deleteTaskById(@PathVariable Long TaskId)
	{
		boolean isUser=TaskService.isTaskExists(TaskId);
		if(isUser)
		{
			TaskService.deleteTaskById(TaskId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllTask(){
		TaskService.deleteAllTask();
	}
}
