package com.project.angel.sgurukul.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.angel.sgurukul.entity.Admin;
import com.project.angel.sgurukul.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired(required=true)
	private AdminService adminService;
	
	@PostMapping("/add")
	public ResponseEntity<Admin> addAdmin(@RequestBody Admin Admin)
	{
		Admin a = adminService.addAdmin(Admin);
		return new ResponseEntity<>(a,HttpStatus.CREATED);
	}
	@GetMapping("/get/{adminId}")
	public ResponseEntity<Admin> getAdmin(@PathVariable Long adminId)
	{
		boolean isAdmin = adminService.isAdminExists(adminId);
		if(isAdmin)
		{
			Admin a=adminService.getAdminById(adminId);
			return new ResponseEntity<>(a,HttpStatus.OK);
		}
		else
		{
			System.out.print("No user found");
			return null;
		}
	}
	@GetMapping("/getAll")
	public ResponseEntity<List<Admin>> getAllAdmin(){
		return new ResponseEntity<>(adminService.getAllAdmin(),HttpStatus.OK);
	}
	@PutMapping("/update/{adminId}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable Long adminId,@RequestBody Admin a)
	{
		boolean isAdmin=adminService.isAdminExists(adminId);
		if(isAdmin)
		{
			return new ResponseEntity<>(adminService.updateAdmin(adminId, a),HttpStatus.OK);
		}
		else {
			System.out.print("No user found");
			return null;
		}
	}
	@DeleteMapping("/delete/{adminId}")
	public void deleteAdminById(@PathVariable Long adminId)
	{
		boolean isAdmin=adminService.isAdminExists(adminId);
		if(isAdmin)
		{
			adminService.deleteAdminById(adminId);
		}
		else
		{
			System.out.print("No user found");
		}
	}
	@DeleteMapping("/deleteAll")
	public void deleteAllAdmin(){
		adminService.deleteAllAdmin();
	}
}
