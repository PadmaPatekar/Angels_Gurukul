package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.angel.sgurukul.entity.Faculty;
import com.project.angel.sgurukul.repository.FacultyRepository;
import com.project.angel.sgurukul.service.FacultyService;

@Service
public class FacultyServiceImpl implements FacultyService{

	@Autowired
	 private FacultyRepository facultyRepo;
   
	@Override
	public Faculty addFaculty(Faculty Faculty) {
		return facultyRepo.save(Faculty);
	}

	@Override
	public List<Faculty> getAllFaculty() {
		return facultyRepo.findAll();
	}

	@Override
	public Faculty getFacultyById(Long facultyId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return facultyRepo.findById(facultyId).get();
	}

	@Override
	public Faculty updateFaculty(Long facultyId,Faculty Faculty) {
		Faculty f=facultyRepo.findById(facultyId).get();
		f.setFirstName(Faculty.getFirstName());
		f.setLastName(Faculty.getLastName());
		f.setEmail(Faculty.getEmail());
		f.setPassword(Faculty.getPassword());
		f.setConfirm_password(Faculty.getConfirm_password());
		return facultyRepo.save(f);
	}

	@Override
	public void deleteFacultyById(Long facultyId) {
		facultyRepo.deleteById(facultyId);
	}

	@Override
	public void deleteAllFaculty() {
		facultyRepo.deleteAll();
		
	}

	@Override
	public boolean isFacultyExists(Long facultyId) {
		return facultyRepo.existsById(facultyId);
	}
}
