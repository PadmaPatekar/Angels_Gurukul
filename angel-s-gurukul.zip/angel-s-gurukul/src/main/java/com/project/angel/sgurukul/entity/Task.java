package com.project.angel.sgurukul.entity;

import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="Task")
public class Task {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long Task_id;
	   @Temporal(TemporalType.TIMESTAMP)
	    @Column(nullable = false)
	    private Date TaskDate;
	    @PrePersist
	    private void onCreate() {
	        TaskDate = new Date();
	    }
	    
	    @Column(nullable = false)
		private String UploadTask;
	    
	    @Column(nullable = false)
	    private String Marks;
	    

	    @ManyToOne(cascade= CascadeType.ALL)
	    @JoinColumn(name="reg_id")
	    private Registration registration1;
	
		public Date getTaskDate() {
			return TaskDate;
		}
		public void setTaskDate(Date taskDate) {
			TaskDate = taskDate;
		}
		public Registration getRegistration1() {
			return registration1;
		}
		public void setRegistration1(Registration registration1) {
			this.registration1 = registration1;
		}
		public Task() {
			super();
			
		}
		public Task(Date TaskDate, String UploadTask,String Marks) {
			super();
			this.TaskDate = TaskDate;
			this.UploadTask = UploadTask;
			this.Marks = Marks;
	}
		public String getUploadTask() {
			return UploadTask;
		}
		public void setUploadTask(String uploadTask) {
			UploadTask = uploadTask;
		}
		public String getMarks() {
			return Marks;
		}
		public void setMarks(String marks) {
			Marks = marks;
		}
		
		
}
