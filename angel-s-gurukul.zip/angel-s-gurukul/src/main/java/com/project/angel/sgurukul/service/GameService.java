package com.project.angel.sgurukul.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.project.angel.sgurukul.entity.Game;
@Component
public interface GameService {

   Game addGame(Game Game);
	
	List<Game> getAllGame();
	
	Game getGameById(Long GameId);
	
	Game updateGame(Long GameId,Game Game);
	
	void deleteGameById(Long GameId);
	
	void deleteAllGame();
	
	boolean isGameExists(Long GameId);
}
