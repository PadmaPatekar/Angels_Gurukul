package com.project.angel.sgurukul.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.angel.sgurukul.entity.Task;
import com.project.angel.sgurukul.repository.TaskRepository;
import com.project.angel.sgurukul.service.TaskService;

public class TaskServiceImpl implements  TaskService {

	@Autowired
	 private TaskRepository TaskRepo;
 
	@Override
	public Task addTask(Task Task) {
		return TaskRepo.save(Task);
	}

	@Override
	public List<Task> getAllTask() {
		return TaskRepo.findAll();
	}

	@Override
	public Task getTaskById(Long TaskId) {
		//Optional<User> op=userRepo.findById(userId);
		//return op.get();
		return TaskRepo.findById(TaskId).get();
	}

	@Override
	public Task updateTask(Long TaskId,Task Task) {
		Task t=TaskRepo.findById(TaskId).get();
		t.setUploadTask(Task.getUploadTask());
		t.setMarks(Task.getMarks());
		
			
		return TaskRepo.save(t);
	}

	@Override
	public void deleteTaskById(Long TaskId) {
		TaskRepo.deleteById(TaskId);
	}

	@Override
	public void deleteAllTask() {
		TaskRepo.deleteAll();
		
	}

	@Override
	public boolean isTaskExists(Long TaskId) {
		return TaskRepo.existsById(TaskId);
	}
}
