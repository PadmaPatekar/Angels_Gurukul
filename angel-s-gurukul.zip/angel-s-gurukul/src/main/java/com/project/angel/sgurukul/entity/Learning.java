package com.project.angel.sgurukul.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Learning")
public class Learning {

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long learn_id;
	    @Column(nullable = false)
		private String Title;
	    
	    @Column(nullable = false)
		private String LearningType;
	    
	    @Column(nullable = false)
	    private String Overview;
	    
	    @Column(nullable = false)
	    private String Link;
	
		public Learning() {
			super();
			
		}
		public Learning(String Title, String LearningType,String Overview,String Link) {
			super();
			this.Title = Title;
			this.LearningType = LearningType;
			this.Overview = Overview;
			this.Link = Link;
			
		}
		public String getTitle() {
			return Title;
		}
		public void setTitle(String title) {
			Title = title;
		}
		public String getLearningType() {
			return LearningType;
		}
		public void setLearningType(String learningType) {
			LearningType = learningType;
		}
		public String getOverview() {
			return Overview;
		}
		public void setOverview(String overview) {
			Overview = overview;
		}
		public String getLink() {
			return Link;
		}
		public void setLink(String link) {
			Link = link;
		}
		
}

